#!/bin/bash
#
#
# Copyright 2023-2024 NXP
#
# NXP CONFIDENTIAL
# The source code contained or described herein and all documents related to
# the source code ("Materials") are owned by NXP ( NXP ), its
# suppliers and/or its licensors. Title to the Materials remains with NXP,
# its suppliers and/or its licensors. The Materials contain
# trade secrets and proprietary and confidential information of NXP, its
# suppliers and/or its licensors. The Materials are protected by worldwide copyright
# and trade secret laws and treaty provisions. No part of the Materials may be
# used, copied, reproduced, modified, published, uploaded, posted,
# transmitted, distributed, or disclosed in any way without NXP's prior
# express written permission.
#
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by NXP in writing.
#
#

gdb_mux=${GDB_MUX}
gdb_app=${GDB_APP}

spi_speed=1000000
spi_cs_delay=0

#mux_trace=4:0xffffffff
mux_trace=0:0

# runtime zboss log level for applications
run_level=release
#run_level=debug

# runtime thread log level
thread_log=4

# track error message from zbosss log file: 0: no track, 1: do track
mux_track_log_error=0
app_track_log_error=0

# generate coredump in ./coredump in case of crash of the app
coredump=0

# cleanup all previous execution of zigbee (removes *.log, *.nvram, *.prod, *.dump, *.trace files)
zbclean=0

function usage()
{
	command="${me} [options]"
	echo
	echo "${command}"
	echo
	echo "Mandatory:"
	echo "  --ch <channel>             OpenThread & Zigbee channel to use"
	echo
	echo "Options:"
	echo "  --ot <ot appli>            Openthread application (uart-hdlc) (border router is auto-detected)"
	echo "  --zb <zb appli>            Zigbee application"
	echo "  --fw <firmware>            Firmware file to download (optional)"
	echo
	echo "At least one appli is mandatory, either zigbee or thread"
	echo
	echo "Advanced (optional):"
	echo "  --help                     This help"
	echo "  --spi <speed/Hz>           Configure spi_speed"
	echo "  --csdelay <CS delay/µs>    Configure spi_chip_select_setup_delay"
	echo "  --ieee <ieee_addr>         Configure ieee address (zigbee)"
	echo "  --otcfg <router|reed|fed>  Configure thread role (requires --otnet)"
	echo "  --otnet <create|join>      Create or join existing thread (required by --otcfg)"
	echo "  --brbb <ifname>            Configure otbr-agent backbone (default: eth0), used only if \'ot appli\' is detected as otbr-agent"
	echo "  --ping <ipv6_addr>         Ping <ipv6_addr> with 1K payload, requires to configure thread role & having a otbr-agent between <ipv6_addr> and the thread network"
	echo
	echo "The first appli started is the first one provided in the list of arguments"
	echo "Start Thread then Zigbee: ${me} --ch <channel> --ot <thread appli> --zb <zb appli> [--fw <firmware>]"
	echo "Start Zigbee then Thread: ${me} --ch <channel> --zb <zb appli> --ot <thread appli> [--fw <firmware>]"
	echo
	echo "Note: to be able to run a Zigbee application with a console (zb_cli, ...), it needs"
	echo "- to run alone (without Thread application)"
	echo "- to run second (with Thread appliaction started first)"
	echo "Note: same restrictions to be able to restart Zigbee application"
	echo
	echo "Debugging:"
	echo "  --zberr                    Track zb_mux & zb appli errors in zboss log file"
	echo "  --dbgspi <0~3>             zb_mux debug SPI frames, bit field: 0: no log, 1: dump SPI header, 2: dump SPI data, 3: both raw & interpreted"
	echo "  --dbgspinel <0~3>          zb_mux debug SPINEL frames, bit field: 0: no log, 1: dump SPINEL Raw data, 2: dump SPINEL interpreted data, 3: both raw & interpreted"
	echo "  --otlog <0~6>              Openthread application log level (verbose forced)"
	echo "  --dbgtty <0~3>             zb_app debug TTY frames, bit field: 0: dump TTY Raw data, 2: dump SPINEL in TTY-HDLC interpreted data, 3: both raw & interpreted"
	echo "  --muxout <0~3>             zb_mux output bit field: 0: no log (wcs) on console, 1: log (wcs) on console (default), 2: log (wcs) on file zb_mux.console, 3: both"
	echo "  --zbout <0~3>              zb_app output bit field: 0: no log (wcs) on console, 1: log (wcs) on console (default), 2: log (wcs) on file zb_app.console, 3: both"
	echo "  --zblog <debug|release>    Zigbee Zboss log level (on file ${zb_app}.log)"
	echo "  --gdbmux <port>            gdb debugging zb_mux on port specified"
	echo "  --gdbapp <port>            gdb debugging zb_app on port specified"
	echo "  --core                     generate coredump in ./coredumps in case of crash of the app (useful for debug build only)"
	echo "  --zbclean                  cleanup all previous execution of zigbee (removes *.log, *.nvram, *.prod, *.dump, *.trace files)"
	echo "  --logsh <postlogrotatesh>  script to be called by zb_mux/zb_app after a log file is rotated (every 50MB, keep only 3 last logs)"
	echo
	echo "spi_speed:   ${spi_speed}"
	echo "mux_trace:   ${mux_trace}"
	echo "run_level:   ${run_level}"
	echo "thread_log:  ${thread_log}"
	echo "DUMP_SPI:    ${DUMP_SPI}"
	echo "DUMP_SPINEL: ${DUMP_SPINEL}"
	echo "DUMP_TTY:    ${DUMP_TTY}"
	echo
}

function validate_firmware()
{
	if [ -z "${firmware}" ]; then
		# Firmware is optional, do not fail
		echo "No Firmware configured"; return
	fi
	if [ ! -f ${firmware} ]; then
		echo "Firmware file ${firmware} does not exist"; echo "usage: ${me} --help"; exit 1
	fi
}
function validate_channel()
{
	if [ ${channel} -lt 11 ] || [ ${channel} -gt 26 ]; then
		echo "Invalid zigbee channel ${channel}"; echo "usage: ${me} --help"; exit 1
	fi
}
function validate_zb_app()
{
	if [ -z "${zb_app}" ]; then
		echo "No Zigbee Application configured"; echo "usage: ${me} --help"; exit 1
	fi
	if [ ! -f ${zb_app} ]; then
		echo "Application file ${zb_app} does not exist"; echo "usage: ${me} --help"; exit 1
	fi
	if [ -z "${first}" ]; then
		first=zb_app
	else
		second=zb_app
	fi
}
function validate_ot_app()
{
	if [ -z "${ot_app}" ]; then
		echo "No Openthread Application configured"; echo "usage: ${me} --help"; exit 1
	fi
	if [ ! -f ${ot_app} ]; then
		echo "Application file ${ot_app} does not exist"; echo "usage: ${me} --help"; exit 1
	fi
	if [ -z "${first}" ]; then
		first=ot_app
	else
		zb_cli=`echo ${zb_app} | grep -c "cli_nxp"`
		if [ ${zb_cli} -gt 0 ]; then
			echo "Application Zigbee ${zb_app} is a CLI, it cannot be run first in dualpan (would be in background)"; echo "usage: ${me} --help"; exit 1
		else
			second=ot_app
		fi
	fi

	# otbr-agent uses DBus, not ot-daemon
	res=`objdump -x ${ot_app} | grep -c "DBusMessageExtract\|DBusMessageEncode"`
	if [ ${res} -gt 0 ]; then
		otbr=yes
	else
		otbr=no
	fi
}
function validate_ot_cfg()
{
	case ${ot_cfg} in
		# FTD:
		router|Router|ROUTER) ot_cfg=router ;;
		reed|Reed|REED)       ot_cfg=reed   ;;
		fed|Fed|FED)          ot_cfg=fed    ;;
		# MTD:
#		med|Med|MED)          ot_cfg=med    ;;
#		sed|Sed|SED)          ot_cfg=sed    ;;
		# Error:
		*)  echo "Unknown Thread config: ${ot_cfg}"; echo "usage: ${me} --help"; exit 1
	esac
}
function validate_ot_net()
{
	case ${ot_net} in
		create|Create|CREATE) ot_net=create ;;
		join|Join|JOIN)       ot_net=join    ;;
		*)  echo "Unknown Thread Network: ${ot_net}"; echo "usage: ${me} --help"; exit 1
	esac
}

# Parse args
me=$0
channel=""
first=""
second=""
otbr=undefined
otbr_backbone=eth0
otbr_ping=""
ot_net=""

# for zb_mux
# Bit field: 0: no log (wcs) on console, 1: log (wcs) on console, 2: log (wcs) on file zb_mux.console, 3: both
export ZB_MUX_OUT=1
# Bit field: 0: no log, 1: dump SPI header, 2: dump SPI data, 3: both
export DUMP_SPI=0
# Bit field: 0: no log, 1: dump SPINEL Raw data, 2: dump SPINEL interpreted data, 3: both
export DUMP_SPINEL=0

# for ${zb_app}
# Bit field: 0: no log (wcs) on console, 1: log (wcs) on console, 2: log (wcs) on file $(zb_app).console, 3: both
export ZB_APP_OUT=1
# Bit field: 0: no log, 1: dump TTY Raw data, 2: dump SPINEL in TTY-HDLC interpreted data, 3: both
export DUMP_TTY=0


while [ "$#" -gt 0 ]; do
	case $1 in
	--help)      usage; exit 0;;
	# mandatory
	--ch)        shift; channel=$1;   validate_channel  ;;
	# at least one
	--zb)        shift; zb_app=$1;    validate_zb_app   ;;
	--ot)        shift; ot_app=$1;    validate_ot_app   ;;
	# optional
	--fw)        shift; firmware=$1;  validate_firmware ;;
	--spi)       shift; spi_speed=$1  ;;
	--csdelay)   shift; spi_cs_delay=$1 ;;
	--ieee)      shift; ieee_addr=$1  ;;
	--otcfg)     shift; ot_cfg=$1;    validate_ot_cfg   ;;
	--otnet)     shift; ot_net=$1;    validate_ot_net   ;;
	--brbb)      shift; otbr_backbone=$1 ;;
	--ping)      shift; otbr_ping=$1 ;;
	# debug
	--zberr)     mux_track_log_error=1; app_track_log_error=1 ;;
	--zblog)     shift; run_level=$1                          ;;
	--otlog)     shift; thread_log="$1 -v"                    ;;
	--muxout)    shift; export ZB_MUX_OUT=$1                  ;;
	--zbout)     shift; export ZB_APP_OUT=$1                  ;;
	--dbgspi)    shift; export DUMP_SPI=$1                    ;;
	--dbgspinel) shift; export DUMP_SPINEL=$1                 ;;
	--dbgtty)    shift; export DUMP_TTY=$1                    ;;
	--gdbmux)    shift; gdb_mux=$1                            ;;
	--gdbapp)    shift; gdb_app=$1                            ;;
	--core)      coredump=1                                   ;;
	--zbclean)   zbclean=1                                    ;;
	--logsh)     shift; export ZB_LOGFILE_POST_ROTATE_SH=$1   ;;
	*)           echo "Unknown option $1"; echo "usage: ${me} --help"; exit 1 ;;
	esac
	shift
done
if [ -z "${channel}" ]; then
	echo "No channel provided"; echo "usage: ${me} --help"; exit 1
fi
if [ -z "${first}" ]; then
	echo "No application provided"; echo "usage: ${me} --help"; exit 1
fi
if [ -n "${ot_cfg}" ] && [ -z "${ot_net}" ]; then
	echo "For --otcfg option, need to define if we create a new network or join an existing one using --otnet <create|join>"; echo "usage: ${me} --help"; exit 1
fi

me_5sum=`md5sum ${me} | awk '{print $1}' | cut -b 1-15`
if [ -n  "${firmware}" ]; then
  fw_5sum=`md5sum ${firmware} | awk '{print $1}' | cut -b 1-15`
else
  fw_5sum=""
fi

echo "me:       ${me} ${me_5sum}"
echo "version:  release 019.82"
echo "channel:  ${channel}"
echo "first:    ${first}"
echo "second:   ${second}"
echo "zb_app:   ${zb_app}"
if [ "${otbr}" = "yes" ]; then
	echo "ot_app:   ${ot_app} ${ot_cfg} backbone: ${otbr_backbone}"
else
	echo "ot_app:   ${ot_app} ${ot_cfg}"
fi
echo "firmware: ${firmware} ${fw_5sum}"


# ---------- OT_APP ----------
# define tty device to use
export OT_TTY=/tmp/ttyOpenThread
export OT_CHANNEL=${channel}

# ---------- ZB_APP ----------
# define tty device to use
export MACSPLIT_TTY=/tmp/ttyZigbee
# define channel to use (except for CLI)
export MACSPLIT_CHANNEL=${channel}
# define prompt to use (for multitest app), it alsoo reduce to 0.5s the delay before getting the prompt
export MACSPLIT_PROMPT="> "
# define zboss trace level & mask
if [ "${run_level}" = "release" ]; then
	echo "run_level in ${run_level} mode"
	export ZB_TRACE_LEVEL=4
	export ZB_TRACE_MASK=0x00000800
elif [ "${run_level}" = "debug" ]; then
	echo "run_level in ${run_level} mode"
	export ZB_TRACE_LEVEL=4
	export ZB_TRACE_MASK=0xffffffff
else
	echo "run_level in unknown mode"
	export ZB_TRACE_LEVEL=0
	export ZB_TRACE_MASK=0x00000000
fi
if [ -n "${ieee_addr}" ]; then
	# Optional, extra config disabled by default, keep value configured by zb_set_long_address() in ${zb_app}:MAIN()
	#export MACSPLIT_IEEE_ADDR=aa:aa:aa:aa:aa:aa:36:15
	export MACSPLIT_IEEE_ADDR=${ieee_addr}
fi


# Check hardware setting to adapt config
soc_id=`cat /sys/devices/soc0/soc_id`
echo "Hardware config: ${soc_id}"
case ${soc_id} in
	i.MX8MM|i.MX8MN|i.MX8MP)
		fw_dld_dev="/dev/ttymxc2"
		spi_dev="/dev/spidev1.0"
		gpio_int_dev=gpiochip5
		gpio_int_lin=12
		gpio_reset_dev=gpiochip5
		gpio_reset_lin=13
		reset_method="button"
		;;
	i.MX93|i.MX91)
		fw_dld_dev="/dev/ttyLP4"
		spi_dev="/dev/spidev0.0"
		gpio_int_dev=gpiochip5
		gpio_int_lin=10
		gpio_reset_dev=gpiochip4
		gpio_reset_lin=1
		if [ "${IMX93_RESET_IW612}" = "gpio" ]; then
			# Activating reset using gpio behaves on IMX93 like a full IW612 reset (both BT & WiFi)
			# export IMX93_RESET_IW612="gpio"
			reset_method="gpio"
			#
			# Please use the dtb imx93-11x11-evk-ffu_gpio_irq_free_5-20_4-0-4-1.dtb
			# and check:
			# gpioinfo --chip gpiochip5 20:
			# => gpiochip5 20    unnamed                 input
			# gpioinfo --chip gpiochip4 0:
			# => gpiochip4 0     unnamed                 input
			# gpioinfo --chip gpiochip4 1:
			# => gpiochip4 1     unnamed                 input
			#
			iw612_gpio_reset_dev=gpiochip5
			iw612_gpio_reset_lin=20
			iw612_gpio_spi_ena_dev=gpiochip4
			iw612_gpio_spi_ena_lin=0
			iw612_gpio_ind_rst_dev=gpiochip4
			iw612_gpio_ind_rst_lin=1
		else
			reset_method="none"
		fi
		;;
	*)
		echo "Unknown hardware config"
		exit 1
		;;
esac


function stop_service()
{
	this_app=$1
	if [ -f /lib/systemd/system/${this_app}.service ]; then
		echo "Stop service ${this_app}"
		systemctl stop ${this_app}
	fi
}

function check_and_kill()
{
	this_app=$1

	# follow all /
	if [ `echo ${this_app} | grep -c "/"` -gt 0 ]; then
		check_and_kill `echo ${this_app} | cut -d'/' -f 2-`
		return
	fi

	this_pid=`pidof ${this_app}`
	if [ -n "${this_pid}" ]; then
		echo
		echo "Kill ${this_app}"
		killall ${this_app}
		sleep 1
	fi
}

function init()
{
	# Sanity check
	pid_otbr=`pidof otbr-agent`
	if [ -n "${pid_otbr}" ]; then
		stop_service otbr-firewall
		stop_service otbr-agent
	fi
	check_and_kill otbr-agent
	check_and_kill ot-daemon

	if [ "${otbr}" = "yes" ]; then
		# Stop other services that does Routing Advertisement
		stop_service radvd
		systemctl mask avahi-daemon.socket
		stop_service avahi-daemon
	fi

	if [ -z "${SSH_CONNECTION}" ]; then
		if [ ${DUMP_SPI} -ne 0 ] || [ ${DUMP_SPINEL} -ne 0 ]; then
			if [ ${ZB_MUX_OUT} -eq 1 ] || [  ${ZB_MUX_OUT} -eq 3 ] ;then
				echo ""
				echo ""
				echo "ERROR: debugging SPI|SPINEL is NOT RECOMMANDED over Uart, please use ssh"
				exit 1
			fi
		else
			if [ ${DUMP_TTY} -ne 0 ]; then
				if [ ${ZB_APP_OUT} -eq 1 ] || [  ${ZB_APP_OUT} -eq 3 ] ;then
					echo ""
					echo ""
					echo "ERROR: debugging TTY is NOT RECOMMANDED over Uart, please use ssh"
					exit 1
				fi
			fi
		fi
	fi

	if [ ${zbclean} -ne 0 ]; then
		echo ""
		echo "full zigbee cleanup of previous run"
		rm -f *.log *.log.* *.console *.console.* *.nvram *.prod *.dump *.trace
		rm -rf backup
	fi
}

function purge_coredumps()
{
	if [ ${coredump} -ne 0 ]; then
		core_sigabort=`find coredumps/ -name core-*-sig_6-pid_*`
		echo ""
		for file in ${core_sigabort}; do
			echo "remove core file due to signal abort: ${file}"
			rm -f ${file}
		done
	fi
}

function config_coredump()
{
	mkdir -p ./coredumps
	echo ""
	echo "configure core in ${PWD}/coredumps"
	ulimit -c unlimited
	echo "${PWD}/coredumps/core-%e-sig_%s-pid_%p" > /proc/sys/kernel/core_pattern
	purge_coredumps
}

function cleanup_previous_zb_app()
{
	this_app=$1

	# follow all /
	if [ `echo ${this_app} | grep -c "/"` -gt 0 ]; then
		cleanup_previous_zb_app `echo ${this_app} | cut -d'/' -f 2-`
		return
	fi

	if [ "${this_app}" = "acm_virtualtty_bridge" ]; then
		res=`lsmod | grep -c g_serial`
		if [ ${res} -eq 0 ]; then
			echo "load g_serial"
			modprobe g_serial n_ports=1 > /dev/null 2>&1
		fi
	fi

	if [ ! -f ${this_app}.nvram ]; then
		return
	fi

	# preserve nvram and log of the running apps, it will be removed in case of factory reset
	if [ -f ${this_app}.log ]; then
		mv ${this_app}.log ${this_app}.log.bak
		# removes older log files (since ZB_USE_LOGFILE_ROTATE has been enabled)
		rm -f ${this_app}.log.*
	fi
	if [ -f ${this_app}.console ] && [ ${ZB_APP_OUT} -gt 1 ]; then
		mv ${this_app}.console ${this_app}.console.bak
		# removes older log files (since ZB_USE_LOGFILE_ROTATE has been enabled)
		rm -f ${this_app}.console.*
	fi

	# Clean previous run:
	rm -f ${this_app}.dump ${this_app}.log ${this_app}.console ${this_app}.prod ${this_app}.trace


	# Check if user wants to keep NVRAM files
	echo ""
	read -p "Factory reset for ${this_app} [y/n] ([y] or [Enter]) ? " factory_reset
	case $factory_reset in
		[Nn]*)
			echo "Keep settings in ${this_app}.nvram"
			mv ${this_app}.log.bak ${this_app}.log
			echo "----------------- APPLI ${this_app} restarted ------------------" >> ${this_app}.log
			if [ ${ZB_APP_OUT} -gt 1 ]; then
				mv ${this_app}.console.bak ${this_app}.console
				echo "----------------- APPLI ${this_app} restarted ------------------" >> ${this_app}.console
			fi
			;;
		[Yy]*|*)
			echo "Factory reset: ${this_app}.nvram is removed"
			rm -f ${this_app}.nvram
			rm -f ${this_app}.log.bak
			echo "----------------- APPLI ${this_app} factory reset ------------------" > ${this_app}.log
			if [ ${ZB_APP_OUT} -gt 1 ]; then
				rm -f ${this_app}.console.bak
				echo "----------------- APPLI ${this_app} factory reset ------------------" > ${this_app}.console
			fi
			;;
	esac

	if [ ${app_track_log_error} -ne 0 ]; then
		echo "Track ERROR on ${this_app}.log"
		tail -f ${this_app}.log | grep ERROR | awk -F "ERROR" '{print "[ZB_APP_ERROR"$2}' &
	fi

	# Specific apps
	if [ ${this_app} == "ota_client_zr" ]; then
		echo ""
		read -p "Purge previous OTA files [y/n] ([y] or [Enter]) ? " purge_ota
		case $factory_reset in
			[Yy]*|*)
				echo "OTA-FILE-* are removed"
				rm -f OTA-FILE-*
				;;
		esac
	fi
}

function reset_device()
{
	case ${reset_method} in
		button)
			mlan0cnt=`ifconfig | grep -c "mlan0"`
			if [ ${mlan0cnt} -gt 0 ]; then
				echo "CAUTION: WiFi is running"
				echo "CAUTION: in case WiFi has downloaded a combo (sduart_xxx) firmware, no need to use option [--fw <IW612-firmware>]] here..."
				echo "CAUTION: in any cases, do not push Reset button, it would kill the WiFi"
				read -p "Continue [enter] ?" dummy
			else
				read -p "Push Reset button of device [enter] ? " dummy
			fi
			;;
		gpio)
			# Trick to know if the option --chip is supported or not (introduced on version v2.x)
			gpioinfo -h | grep "\--chip" > /dev/null
			if [ $? -eq 0 ]; then
				option="--chip"
			else
				option=""
			fi
			echo "Reset IW612 (BT-15.4 & WiFi) with ${iw612_gpio_reset_dev}:${iw612_gpio_reset_lin}"
			gpioset ${option} ${iw612_gpio_reset_dev} ${iw612_gpio_reset_lin}=0 &
			sleep 0.5 # Wait action to be done
			killall gpioset &> /dev/null
			sleep 0.5 # Keep reset active
			gpioset ${option} ${iw612_gpio_reset_dev} ${iw612_gpio_reset_lin}=1 &
			sleep 0.5 # Wait action to be done
			killall gpioset &> /dev/null
			echo "Enable IW612 (SPI_ENA=1 & IND_RST_15_4=0)"
			gpioset ${option} ${iw612_gpio_spi_ena_dev} ${iw612_gpio_spi_ena_lin}=1 &
			sleep 0.5 # Wait action to be done
			killall gpioset &> /dev/null
			gpioset ${option} ${iw612_gpio_ind_rst_dev} ${iw612_gpio_ind_rst_lin}=0 &
			sleep 0.5 # Wait action to be done
			killall gpioset &> /dev/null
			;;
		none)
			read -p "Cannot reset the device, would you like to reboot  [y/n] ([n] or [Enter]) ? " do_reboot
			case ${do_reboot} in
				[Yy]*) reboot ;;
				[Nn]*|*) ;;
			esac
			;;
		*)
			echo "Unknown reset_method ${reset_method}, ABORT"
			exit 1
			;;
	esac
}

function flash_firmware()
{
	# If no firmware is provided, bringup up BT in
	echo ""

	if [ -e ${fw_dld_dev} ]; then

		killall hciattach 2> /dev/null

		if [ -n  "${firmware}" ]; then
			echo "Flash ${firmware} with w_loader_imx_lnx on ${fw_dld_dev}"
			echo ""
			reset_device
			fw_loader_imx_lnx ${fw_dld_dev} 115200 0 ${firmware} 3000000
			if [ $? -ne 0 ]; then
				echo "Flash failure, ABORT"
				exit 1
			else
				echo "Wait for the firmware to start..."
				sleep 1
			fi
		fi

		hciattach ${fw_dld_dev} any -s 115200 115200 flow dtron
		sleep 1
	else
		if [ -n  "${firmware}" ]; then
			if [ ! -h /lib/firmware/nxp/uartspi_n61x_v1.bin.se ]; then
				echo "backup original firmware"
				cd /lib/firmware/nxp
				mv uartspi_n61x_v1.bin.se uartspi_n61x_v1.bin.se_original
				cd - > /dev/null
			fi

			rm -f /lib/firmware/nxp/uartspi_n61x_v1.bin.se
			abs_firmware=`readlink -f ${firmware}`
			ln -s ${abs_firmware} /lib/firmware/nxp/uartspi_n61x_v1.bin.se
			this_firmware=`ls -al /lib/firmware/nxp/uartspi_n61x_v1.bin.se | awk -F" -> " '{print $2}'`
			echo "Flash ${firmware} with btnxpuart (symlink on /lib/firmware/nxp/uartspi_n61x_v1.bin.se)"
			echo ""

			bsp_version=`uname -r | awk -F"-g" '{print $1}'`
			res=`lsmod | grep -c btnxpuart`
			if [ ${res} -ne 0 ]; then
				echo "remove btnxpuart"
				rmmod btnxpuart
				sleep 1
			fi
			reset_device
			if [ -n "${SSH_CONNECTION}" ]; then
				tail -f -n 0 /var/log/messages | grep "Bluetooth" &
				tail_pid=$!
			else
				tail_pid=0
			fi
			kernel_lvl=`cat /proc/sys/kernel/printk |  awk '{print $1}'`
			echo 7 > /proc/sys/kernel/printk
			echo "probe btnxpuart"
			modprobe btnxpuart
			# measured timing:
			# +0.6s: request firmware
			# uartspi:
			# +2.2s: firmware downloaded
			# +4.2s: config done (baudrate & wakeup method)
			# sduart: combo
			# +3.5s:  firmware downloaded
			# +5.0s: config done (baudrate & wakeup method)
			sleep 6
			echo ${kernel_lvl} > /proc/sys/kernel/printk
			if [ ${tail_pid} -ne 0 ]; then
				kill -9 ${tail_pid}
			fi
		else
			res=`lsmod | grep -c btnxpuart`
			if [ ${res} -eq 0 ]; then
				echo "probe btnxpuart"
				modprobe btnxpuart
				sleep 3
			fi
		fi
	fi
	sleep 1
	echo "bring up hci0"
	hciconfig hci0 up
	# Disable BT Sleep Mode
	hcitool -i hci0 cmd 3f 23 03 00 00
}

apps_running=0

function start_mux()
{
	gpio_int=${gpio_int_lin}:/dev/${gpio_int_dev}
	gpio_reset=${gpio_reset_lin}:/dev/${gpio_reset_dev}

	rm -rf tmp zb_mux.log zb_mux.console
	echo ""
	if [ -n "${gdb_mux}" ]; then
		read -p "Start zb_mux on gdb port ${gdb_mux} [enter] ? " dummy
		gdbserver :${gdb_mux} ./zb_mux -i ${spi_dev} -o 0:/tmp/ttyOpenThread -o 2:/tmp/ttyZigbee -s -S ${spi_speed} -m 0 -c ${spi_cs_delay} -I ${gpio_int} -R ${gpio_reset} -t ${mux_trace} &
	else
		echo "Start zb_mux"
		./zb_mux -i ${spi_dev} -o 0:/tmp/ttyOpenThread -o 2:/tmp/ttyZigbee -s -S ${spi_speed} -m 0 -c ${spi_cs_delay} -I ${gpio_int} -R ${gpio_reset} -t ${mux_trace} &
	fi
	sleep 1

	if [ ${mux_track_log_error} -ne 0 ]; then
		echo "Track ERROR on zb_mux.log"
		tail -f zb_mux.log | grep ERROR | awk -F "ERROR" '{print "[ZB_MUX_ERROR"$2}' &
	fi
}

function stop_mux()
{
	check_and_kill zb_mux
}

function start_zb_app()
{
	cleanup_previous_zb_app ${zb_app}

	echo ""
	if [ -n "${gdb_app}" ]; then
		read -p "Start Zigbee ${zb_app} on gdb port ${gdb_app} [enter] ? " dummy
		if [ "$second" = "ot_app" ]; then
			# if we have thread app is running in second, we must run in background
			gdbserver :${gdb_app} ./${zb_app} &
		else
			gdbserver :${gdb_app} ./${zb_app}
		fi
	else
		read -p "Start Zigbee ${zb_app} [enter] ? " dummy
		if [ "$second" = "ot_app" ]; then
			# if we have thread app is running in second, we must run in background
			./${zb_app} &
		else
			apps_running=1
			while [ ${apps_running} -eq 1 ]; do
				./${zb_app}
				sleep 1
				purge_coredumps
				echo ""
				read -p "Restart Zigbee ${zb_app} [y/n] ([y] or [Enter]) ? " restart
				case $restart in
					[Nn]*)
						break
						;;
					[Yy]*|*)
						;;
				esac
			done
		fi
	fi

	if [ "${second}" = "ot_app" ]; then
		# We are in background, add a tempo
		sleep 3
		apps_running=1
	else
		# We are running in foreground, if we are here
		echo ""
		echo "Zigbee ${zb_app} has stopped"
		apps_running=0
	fi
}

function stop_zb_app()
{
	check_and_kill ${zb_app}
	is_cli_nxp=`echo ${zb_app} | grep -c "cli_nxp"`
	if [ ${is_cli_nxp} -ne 0 ]; then
		echo "Restore echo input caracters & all special caracters restored to default values"
		stty echo
		stty sane
	fi
}

function reset_thread()
{
	ot-ctl thread stop                   > /dev/null
	ot-ctl ifconfig down                 > /dev/null
	ot-ctl factoryreset                  > /dev/null
	sleep 2
}

function update_network()
{
	echo "Enable IP forwarding"
	echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
# IPv4 not needed since THREAD is IPv6 only
#	echo 1 > /proc/sys/net/ipv4/ip_forward
	echo 2 > /proc/sys/net/ipv6/conf/all/accept_ra
	echo "Update iptables to forward ${otbr_backbone} <-> wpan0"
#	iptables -A FORWARD -i ${otbr_backbone} -o wpan0 -j ACCEPT
#	sleep 0.5
#	iptables -A FORWARD -i wpan0 -o ${otbr_backbone} -j ACCEPT
#	sleep 0.5
	ip6tables -A FORWARD -i ${otbr_backbone} -o wpan0 -j ACCEPT
	sleep 0.5
	ip6tables -A FORWARD -i wpan0 -o ${otbr_backbone} -j ACCEPT
	sleep 0.5
	echo ""
}

function config_thread()
{
	OT_PANID="0x12${OT_CHANNEL}"
	OT_EXTPANID="11111111222222${OT_CHANNEL}"
	OT_NETKEY="00112233445566778899aabbccddee${OT_CHANNEL}"
	OT_NETNAME="DualPan-${OT_PANID}"
# This is configured by dataset init new that should done only by the creator of the network
#	OT_MLPREFIX="FD00:0B${OT_CHANNEL}:0000:0000::"

	# ot_cfg:
	# -------
	# definitions (from https://openthread.io/guides/thread-primer/node-roles-and-types)
	# - Full Thread Device (FTD): radio always on, subs to all-routers mcast, maintains IPv6 addr mappings
	#    - Router
	#    - REED (Router Eligible End Device): can be promoted to a router
	#    - FED (Full End Device): cannot be promoted to a router
	#   associated commands: router, routerdowngradethreshold, routereligible, routeridrange, routerselectionjitter, routerupgradethreshold
	#
	# - Minimal Thread Device (MTD): don't subs to all-routers mcast, fwd all msgs to parent
	#    - MED (Minimal End Device): transceiver always on, no need to poll messages from its parent
	#    - SED (Sleepy End Device):  normally disabled, wakes on occasion to poll messages from its parent
	#
	# OT_MODE:
	# r: rx-on-when-idle
	# d: Full Thread Device
	# n: Full Network Data
	# -: no flags:
	#    * rx-off-when-idle
	#    * Minimal Thread Device
	#    * Stable Network Data
	# rdn: leader
	# -:   sleepy end device
	# rn:  REED
	#
	# OT_RTRUPTH: routerupgradethreshold
	# => the number of active routers on the Thread network partition below which a REED may decide to become a Router
	#
	# OT_RTRDOWNTH: routerdowngradethreshold
	# => the number of active routers on the Thread network partition above which an active router may decide to become a child
	#
	# OT_RTRSELJ: routerselectionjitter
	# => a random period prior to request Router ID for REED
	#
	case ${ot_cfg} in
		# FTD:
		router) OT_MODE="rdn" ; OT_RTREL="enable"  ; OT_RTRUPTH="0" ; OT_RTRDOWNTH=""  ; OT_RTRSELJ="1" ;; # if Child && ActiveRouterCount() < UpgradeThreshold then upgrade to Router
		reed)   OT_MODE="rdn" ; OT_RTREL="enable"  ; OT_RTRUPTH=""  ; OT_RTRDOWNTH="0" ; OT_RTRSELJ="1" ;; # if Router && ActiveRouterCount() > DowngradeThreshold then downgrade to REED
		fed)    OT_MODE="rdn" ; OT_RTREL="disable" ;;
		# MTD:
		med)    OT_MODE="rn"  ;;
		sed)    OT_MODE="-"   ;;
	esac

	reset_thread

	echo "Thread config ${ot_cfg}:"
	if [ ${ot_net} = "create" ]; then
		echo -n " - create network         => "       ; ot-ctl dataset init new
	fi
	echo -n " - channel               ${OT_CHANNEL} => "       ; ot-ctl dataset channel ${OT_CHANNEL}
	echo -n " - panid                 ${OT_PANID} => "         ; ot-ctl dataset panid ${OT_PANID}
	echo -n " - extpanid              ${OT_EXTPANID} => "      ; ot-ctl dataset extpanid ${OT_EXTPANID}
	echo -n " - networkkey            ${OT_NETKEY} => "        ; ot-ctl dataset networkkey ${OT_NETKEY}
	echo -n " - networkname           ${OT_NETNAME} => "       ; ot-ctl dataset networkname ${OT_NETNAME}
#	echo -n " - meshlocalprefix       ${OT_MLPREFIX} => "      ; ot-ctl dataset meshlocalprefix ${OT_MLPREFIX}
	if [ -n "${OT_RTREL}" ];     then echo -n " - routereligible           ${OT_RTREL} => "     ; ot-ctl routereligible ${OT_RTREL} ;               fi
	if [ -n "${OT_RTRUPTH}" ];   then echo -n " - routerupgradethreshold   ${OT_RTRUPTH} => "   ; ot-ctl routerupgradethreshold ${OT_RTRUPTH} ;     fi
	if [ -n "${OT_RTRDOWNTH}" ]; then echo -n " - routerdowngradethreshold ${OT_RTRDOWNTH} => " ; ot-ctl routerdowngradethreshold ${OT_RTRDOWNTH} ; fi
	echo -n " - mode                  ${OT_MODE} => "          ; ot-ctl mode ${OT_MODE}
	ot-ctl dataset commit active         > /dev/null
	if [ -n "${OT_RTRSELJ}" ];   then echo -n " - routerselectionjitter    ${OT_RTRSELJ} => "   ; ot-ctl routerselectionjitter ${OT_RTRSELJ} ;      fi
	ot-ctl ifconfig up                   > /dev/null
	ot-ctl thread start                  > /dev/null
	ot-ctl prefix add fd11:22::/64 pasor > /dev/null
	loop=1
	good=0
	while [ $loop -le 180 ]; do
		state=`ot-ctl state | grep -v "Done" | awk -F"\r" '{print $1}'` # Get rid of \r
		if [ "${prev}" != "${state}" ]; then echo "" ; prev=${state} ; good=0 ; fi
		echo -n -e "Thread state: ${state}${msg}                         \r"
		case ${state} in
#			child)  if [ "${ot_cfg}" = "router" ];  then ot-ctl state router > /dev/null; msg=", force router"; else let good++; msg=" (ok ${good})";  fi ;; # => No, the REED can be leader if started first
			child)  if [ "${ot_cfg}" = "router" ];  then ot-ctl state leader > /dev/null; msg=", force leader"; else let good++; msg=" (ok ${good})"; fi ;;
			leader) if [ "${ot_cfg}" != "router" ]; then ot-ctl state child  > /dev/null; msg=", force child" ; else let good++; msg=" (ok ${good})"; fi ;;
			router) if [ "${ot_cfg}" != "router" ]; then ot-ctl state child  > /dev/null; msg=", force child" ; else let good++; msg=" (ok ${good})"; fi ;;
		esac
		if [ "${good}" -gt 5 ]; then
			meshlocalprefix=`ot-ctl prefix meshlocal | awk -F"/" '{print $1}' | awk -F"::" '{print $1}'`
			addresses=`ot-ctl ipaddr`
			for addr in ${addresses}; do
				case ${addr} in
					fe80:*) ;; # echo "Link-Local Thread Addr: ${addr}" ;;
					fd00:*) ;; # echo "Meld-Local Thread Addr: ${addr}" ;;
					Done*)  ;;
					*) 	# Filter address based on meshhlocalprefix since it is not a real global address
						is_mlp=`echo "${addr}" | grep -c "${meshlocalprefix}"`
						if [ ${is_mlp} -eq 0 ]; then
							echo "Global Thread Address:  ---------------------------------------"
							echo "Global Thread Address:  ${addr}"
							echo "Global Thread Address:  ---------------------------------------"
						fi
						;;
				esac
			done
			echo ""
			ot-ctl dataset active | grep "Mesh Local Prefix"
			echo "DONE"
			ifconfig wpan0
			echo ""
			if [ "${otbr}" = "yes" ]; then
				update_network
			fi

			if [ -n "${otbr_ping}" ]; then
				read -p "Ping 1K on wpan0 ${otbr_ping} [enter] ? " dummy
				if [ "${second}" = "zb_app" ]; then
					# Need to run it in background in case we still have to start_zb_app
					ping -I wpan0 -6 ${otbr_ping} -s 1024 &
				else
					ping -I wpan0 -6 ${otbr_ping} -s 1024
				fi
			fi
			return
		fi
		sleep 1
		let loop++
	done
	echo -e "\nTimeout getting ${ot_cfg} state :("
}

function start_ot_app()
{
	echo ""
	case ${otbr} in
		yes)
			read -p "Start OpenThread BorderRouter ${ot_app} ${ot_cfg}, backbone ${otbr_backbone} [enter] ? " dummy
			./${ot_app} -d ${thread_log} -I wpan0 -B ${otbr_backbone} 'spinel+hdlc+uart://'${OT_TTY} trel://${otbr_backbone} &
			;;
		no|*)
			read -p "Start OpenThread ${ot_app} ${ot_cfg} [enter] ? " dummy
			./${ot_app} 'spinel+hdlc+uart://'${OT_TTY} -d ${thread_log}  &
			;;
	esac

	if [ "${second}" = "zb_app" ]; then
		sleep 3
	fi
	apps_running=1
	sleep 2
	fwversion=`ot-ctl fwversion | grep IWX12`
	echo ""
	echo "Firmware version: ${fwversion}"
	if [ -n "${ot_cfg}" ]; then
		config_thread
	fi
}

function stop_ot_app()
{
	if [ -n "${otbr_ping}" ] && [ -n "${ot_cfg}" ]; then
		check_and_kill ping
	fi
	check_and_kill ${ot_app}
}

function stop_all()
{
	if [ ${app_track_log_error} -ne 0 ] || [ ${mux_track_log_error} -ne 0 ]; then
		check_and_kill tail
	fi
	[ -n "${second}" ] && stop_${second} || true
	stop_${first}
	stop_mux
	#  Get rid of colors (end)
	sed 's/\x06//g' -i *.console &> /dev/null
}

function ctrl_c()
{
	echo ""
	echo "Interrupted by user..."
	stop_all
	exit 0
}

trap ctrl_c INT

init
stop_all
[ ${coredump} -ne 0 ] && config_coredump || true
flash_firmware
start_mux
start_${first}
[ -n "${second}" ] && start_${second} || true
while [ ${apps_running} -eq 1 ]; do
	sleep 1
done
stop_all

